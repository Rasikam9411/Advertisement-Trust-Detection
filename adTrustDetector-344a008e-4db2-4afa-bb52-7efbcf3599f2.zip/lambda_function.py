
import boto3
import csv
import io
import json

s3 = boto3.client("s3")

BUCKET = "rasika-ad-analytics"
OUTPUT_FILE = "results/ad_detection_result.csv"

def lambda_handler(event, context):

    # Sample advertisement data
    ads = [
        ["A101", "Nike", 120, 24, 90],
        ["A102", "Unknown Brand", 90, 8, 40],
        ["A103", "Apple", 250, 65, 95],
        ["A104", "Unknown Brand", 30, 2, 25]
    ]

    famous_brands = {
        "nike", "apple", "adidas", "samsung",
        "amazon", "microsoft", "coca-cola"
    }

    columns = [
        "Ad ID", "Brand Name", "Clicks", "Conversions",
        "Reputation", "Famous Brand", "Ad Status"
    ]

    results = []

    for ad_id, brand, clicks, conversions, reputation in ads:

        famous = brand.lower() in famous_brands

        if conversions <= 2 or reputation < 70:
            status = "Fake Ad"
        else:
            status = "Trusted Ad"

        results.append({
            "Ad ID": ad_id,
            "Brand Name": brand,
            "Clicks": clicks,
            "Conversions": conversions,
            "Reputation": reputation,
            "Famous Brand": "Yes" if famous else "No",
            "Ad Status": status
        })

    # Create CSV table in memory
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=columns)
    writer.writeheader()
    writer.writerows(results)

    csv_data = buffer.getvalue()

    # Store the results in S3
    s3.put_object(
        Bucket=BUCKET,
        Key=OUTPUT_FILE,
        Body=csv_data.encode("utf-8"),
        ContentType="text/csv"
    )

    # Print a readable table in CloudWatch logs
    widths = {
        col: max(
            len(col),
            max(len(str(row[col])) for row in results)
        )
        for col in columns
    }

    header = " | ".join(
        col.ljust(widths[col]) for col in columns
    )

    separator = "-+-".join(
        "-" * widths[col] for col in columns
    )

    rows = [
        " | ".join(
            str(row[col]).ljust(widths[col])
            for col in columns
        )
        for row in results
    ]

    table = "\n".join([header, separator] + rows)

    print("\nADVERTISEMENT TRUST DETECTION RESULTS\n")
    print(table)

    # Return structured results and S3 location
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "message": "Advertisement analysis completed successfully",
            "results": results,
            "s3_location": f"s3://{BUCKET}/{OUTPUT_FILE}"
        })
    }
